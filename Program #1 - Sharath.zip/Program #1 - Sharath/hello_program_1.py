#Sharath Chandra Reddy Dumpali
#Student Id: 00864049
#This program prints 'Hello World!' to STDOUT/terminal.
print("Hello World!")