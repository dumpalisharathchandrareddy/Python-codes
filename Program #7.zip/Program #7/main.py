# Import menu function from fnct.py and run the program
from fnct import display_menu

# Start program with menu interface
if __name__ == "__main__":
    display_menu()
