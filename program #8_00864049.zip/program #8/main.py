# Import the PolyEval class 
from fnct import PolyEval

# Main of the program as program starts from here
if __name__ == "__main__":
    # Creating an object of Polynomial Evaluator function
    evaluator = PolyEval()
    # Display menu
    evaluator.display_menu()
